import { Component } from '@angular/core';

@Component({
  selector: 'app-home-review',
  templateUrl: './home-review.component.html',
  styleUrls: ['./home-review.component.css']
})
export class HomeReviewComponent {

}
