import { Component } from '@angular/core';

@Component({
  selector: 'app-display-payment-by-booking-id',
  templateUrl: './display-payment-by-booking-id.component.html',
  styleUrls: ['./display-payment-by-booking-id.component.css']
})
export class DisplayPaymentByBookingIdComponent {

}
