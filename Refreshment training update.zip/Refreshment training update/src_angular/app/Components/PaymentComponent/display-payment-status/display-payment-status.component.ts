import { Component } from '@angular/core';

@Component({
  selector: 'app-display-payment-status',
  templateUrl: './display-payment-status.component.html',
  styleUrls: ['./display-payment-status.component.css']
})
export class DisplayPaymentStatusComponent {

}
