import { Component } from '@angular/core';

@Component({
  selector: 'app-home-payment',
  templateUrl: './home-payment.component.html',
  styleUrls: ['./home-payment.component.css']
})
export class HomePaymentComponent {

}
