import { Component } from '@angular/core';

@Component({
  selector: 'app-dealer-home',
  templateUrl: './dealer-home.component.html',
  styleUrls: ['./dealer-home.component.css']
})
export class DealerHomeComponent {

}
