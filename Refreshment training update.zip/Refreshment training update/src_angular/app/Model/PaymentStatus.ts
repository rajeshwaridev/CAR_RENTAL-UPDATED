export interface  PaymentStatus{
     paymentId:number,
     status:string
}